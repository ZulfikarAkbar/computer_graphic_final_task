var start = false;
var ctx;
var canvasState = 1; //point = 1, line = 2, rectangle = 3
var origX = 0;
var origY = 0;
var pixelWidth = 15;

function setWidth(selObj) {
	pixelWidth = parseInt(selObj.value);
}

function setColor(selObj) {
    ctx.fillStyle=selObj.value;
}

function drawPixel(x, y) {
	ctx.fillRect(x * pixelWidth, y * pixelWidth, pixelWidth, pixelWidth);
}

//Tugas kalian adalah mengubah 2 fungsi berikut
function drawLine(x1, y1, x2, y2) {
    alert("Gambar garis dari (" + x1 + ", " + y1 + ") hingga (" + x2 + ", " + y2 + ")");
}

function drawRectangle(x1, y1, x2, y2) {
    alert("Gambar persegi panjang dari (" + x1 + ", " + y1 + ") hingga (" + x2 + ", " + y2 + ")");
}

//Batas akhir yang diedit
//Jangan mengubah selain kedua fungsi di atas

function clearArea() {
  // Use the identity matrix while clearing the canvas
  ctx.setTransform(1, 0, 0, 1, 0, 0);
  ctx.clearRect(0, 0, ctx.canvas.width, ctx.canvas.height);
}

function setPoint() {
	canvasState = 1;
    start = false;
	document.getElementById("the_state").innerHTML = "&nbsp;POINT&nbsp;";
}

function setLine() {
	canvasState = 2;
    start = false;
	document.getElementById("the_state").innerHTML = "&nbsp;LINE&nbsp;";
}

function setRectangle() {
	canvasState = 3;
    start = false;
	document.getElementById("the_state").innerHTML = "&nbsp;RECTANGLE&nbsp;";
}

function init() {
	var CANVAS=document.getElementById("the_canvas");
	CANVAS.width=window.innerWidth;
	CANVAS.height=window.innerHeight - 30;
	ctx = CANVAS.getContext("2d");
	CANVAS.onmousedown = function(e){
		var xx = Math.trunc(e.x / pixelWidth);
		var yy = Math.trunc(e.y / pixelWidth);
		if(canvasState == 1) {
			drawPixel(xx, yy);
		} else if(!start) {
			start = true;
			origX = xx;
			origY = yy;
		} else {
			start = false;
			if(canvasState == 2) {
				drawLine(origX, origY, xx, yy);
			} else if(canvasState == 3) {
				drawRectangle(origX, origY, xx, yy);
			}
		}
	};
}

